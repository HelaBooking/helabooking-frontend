
export const USER_API_BASE_URL = 'https://studious-guide-555j7pqx57q34946-8081.app.github.dev/api';
export const EVENT_API_BASE_URL = 'https://studious-guide-555j7pqx57q34946-8082.app.github.dev/api';
export const BOOKING_API_BASE_URL = 'https://studious-guide-555j7pqx57q34946-8083.app.github.dev/api';
